/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

/**
 *
 * @author felipecovapacheco
 */
public class DefaultHelper {
    
    protected String nombre;
    protected double[] distancias;
    
    public DefaultHelper(String nombre, double[] distancias) {
        this.nombre = nombre;
        this.distancias = distancias;
    }
}